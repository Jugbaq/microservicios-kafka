package com.example.kafka.service;

import com.example.kafka.model.AuditLog;
import com.example.kafka.service.mapper.AuditMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class KafkaMessageService implements KafkaService{

    private final ObjectMapper objectMapper;

    private final DocumentService documentService;

    private final AuditMapper auditMapper;

    @Override
    public void processMessage(String message) {
        try {
            AuditLog auditLog = objectMapper.readValue(message, AuditLog.class);
            System.out.println("auditLogin: "+auditLog.toString());
            documentService.save(auditLog);
        } catch (JsonMappingException e) {
            e.printStackTrace();
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        System.out.println("Received message: " + message);
    }

}
