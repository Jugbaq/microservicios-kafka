package com.example.kafka.service;

import com.example.kafka.entity.Audit;
import com.example.kafka.model.AuditLog;
import com.example.kafka.repository.AuditRepository;
import com.example.kafka.service.mapper.AuditMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService{

    private final AuditRepository auditRepository;

    @Override
    public Audit save(AuditLog auditLog) {
        try {
            Audit audit = mapperAuditLogToAudit(auditLog);
            Audit savedAudit = auditRepository.save(audit);
            return savedAudit;
        } catch (Exception e) {
            return Audit.builder().build();
        }
    }

    private Audit mapperAuditLogToAudit(AuditLog auditLog){
        return Audit.builder()
                .auditLog(auditLog.getAuditLog())
                .recordingDate(auditLog.getRecordingDate())
                .recordingUser(auditLog.getRecordingUser())
                .payload(auditLog.getPayload())
                .build();
    }
}
