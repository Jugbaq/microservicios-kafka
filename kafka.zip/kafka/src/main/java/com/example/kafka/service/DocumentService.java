package com.example.kafka.service;

import com.example.kafka.entity.Audit;
import com.example.kafka.model.AuditLog;

public interface DocumentService {
    Audit save(AuditLog auditLog);
}
