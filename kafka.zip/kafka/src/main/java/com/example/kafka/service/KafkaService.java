package com.example.kafka.service;

public interface KafkaService {
    void processMessage(String message);
}
