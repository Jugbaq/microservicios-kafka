package com.example.kafka.listener;

import com.example.kafka.service.KafkaService;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class KafkaListenerService {

    private final KafkaService kafkaService;


    @KafkaListener(topics = "${kafka.consumer.topic}", groupId = "${kafka.consumer.groupId}")
    public void processMessage(String message) {
        kafkaService.processMessage(message);
    }

}
