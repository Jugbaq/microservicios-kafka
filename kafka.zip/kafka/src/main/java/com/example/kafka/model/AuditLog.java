package com.example.kafka.model;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.kafka.support.SendResult;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@Builder
@Setter
@Getter
public class AuditLog {
    private UUID auditLog;
    private LocalDate recordingDate;
    private String recordingUser;
    private Map<String, Object> payload;
}
