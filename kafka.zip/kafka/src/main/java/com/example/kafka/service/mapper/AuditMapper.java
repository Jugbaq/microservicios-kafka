package com.example.kafka.service.mapper;

import com.example.kafka.entity.Audit;
import com.example.kafka.model.AuditLog;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface AuditMapper {
    Audit setAuditLogToAudit(AuditLog audit);

}
