package com.example.account.service;

import com.example.account.model.account.AccountModel;

import java.util.List;
import java.util.UUID;

public interface AccountService {
    List<AccountModel> listAccountByCustomer(UUID idCustomer);
    AccountModel saveAccount(AccountModel accountInput);

}
