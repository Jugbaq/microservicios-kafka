package com.example.account.model.event;

import com.example.account.model.account.AccountModel;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Setter
@Getter
@Builder
public class EventLog {
    private UUID auditLog;
    private LocalDate recordingDate;
    private String recordingUser;
    private AccountModel payload;

    @Override
    public String toString() {
        return "{" +
                "\"auditLog\":\"" + auditLog + "\"" +
                ", \"recordingDate\":\"" + recordingDate + "\"" +
                ", \"recordingUser\":\"" + recordingUser + "\"" +
                ", \"payload\":\"" + payload + "\"" +
                '}';
    }
}
