package com.example.account.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;

@Table(name="account")
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class Account implements Serializable {

    @Id
    @GeneratedValue(generator = "uuid2")
    @GenericGenerator(name = "uuid2", strategy = "uuid2")
    @Column(name = "id_account", updatable = false, nullable = false, columnDefinition = "VARCHAR(36)")
    private String accountId;

    @Column(name = "number_account")
    private String accountNumber;

    @Column(name = "id_customer")
    private String idCustomer;

    @Column(name = "account_type")
    private String accountType;

    @Column(name = "status")
    private String status;

    @Column(name = "account_balance")
    private BigDecimal accountBalance;

    @Column(name = "opening_date")
    private LocalDate openingDate;

}
