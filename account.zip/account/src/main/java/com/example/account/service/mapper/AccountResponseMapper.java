package com.example.account.service.mapper;

import com.example.account.entity.Account;
import com.example.account.model.account.AccountModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface AccountResponseMapper {
    @Mapping(target="accountStatus", source = "status")
    @Mapping(target="idAccount", source = "accountId")
    AccountModel setFromAccountToAccountModel(Account account);

    @Mapping(target="status", source = "accountStatus")
    @Mapping(target="accountId", source = "idAccount")
    Account setFromAccountModelToAccount(AccountModel card);
}
