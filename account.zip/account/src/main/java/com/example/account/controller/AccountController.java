package com.example.account.controller;

import com.example.account.controller.mapper.AccountMapper;
import com.example.account.model.account.AccountInput;
import com.example.account.model.account.AccountListResponse;
import com.example.account.model.account.AccountResponse;
import com.example.account.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;


@RequiredArgsConstructor
@RestController
@RequestMapping("/api/accounts")
public class AccountController{

    private final AccountService accountService;
    private final AccountMapper accountMapper;

    @GetMapping(value = "/{idCustomer}")
    public ResponseEntity<AccountListResponse> listAccounts(@PathVariable String idCustomer) {
        List<AccountResponse> accountResponse = accountService.listAccountByCustomer(UUID.fromString(idCustomer))
                .stream()
                .map(accountMapper::setFromAccountModelToAccountResponse)
                .collect(Collectors.toList());

        return accountResponse.isEmpty() ? ResponseEntity.noContent().build() :
                ResponseEntity.ok( AccountListResponse.builder()
                        .accounts(accountResponse)
                        .build());
    }

    @PostMapping
    public ResponseEntity<AccountResponse> registerAccount(@RequestBody AccountInput accountInput) {
       return Optional.ofNullable(accountService.saveAccount(accountMapper.setFromAccountInputToAccountModel(accountInput)))
               .map(savedAccount -> ResponseEntity.status(savedAccount.getIdAccount() != null ? HttpStatus.CREATED : HttpStatus.NO_CONTENT)
                       .body(accountMapper.setFromAccountModelToAccountResponse(savedAccount)))
               .orElse(ResponseEntity.notFound().build());
    }
}
