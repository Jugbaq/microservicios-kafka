package com.example.account.controller.mapper;

import com.example.account.model.account.AccountInput;
import com.example.account.model.account.AccountModel;

import com.example.account.model.account.AccountResponse;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants.ComponentModel;

@Mapper(componentModel = ComponentModel.SPRING)
public interface AccountMapper {
    AccountResponse setFromAccountModelToAccountResponse(AccountModel account);

    AccountModel setFromAccountInputToAccountModel(AccountInput account);
}
