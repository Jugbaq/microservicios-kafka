package com.example.account.service;

import com.example.account.entity.Account;
import com.example.account.model.account.AccountModel;
import com.example.account.model.event.EventLog;
import com.example.account.producer.KafkaEventProducer;
import com.example.account.repository.AccountRepository;
import com.example.account.service.mapper.AccountResponseMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

    private final AccountRepository accountRepository;

    private final AccountResponseMapper accountResponseMapper;

    private final KafkaEventProducer kafkaEventProducer;

    private final ObjectMapper objectMapper;

    @Override
    public List<AccountModel> listAccountByCustomer(UUID idCustomer) {
        return accountRepository.findByIdCustomer(idCustomer.toString())
                .stream()
                .map(accountResponseMapper::setFromAccountToAccountModel)
                .collect(Collectors.toList());
    }

    @Override
    public AccountModel saveAccount(AccountModel accountModel) {
        try {
            Account savedAccount = accountRepository.save(accountResponseMapper.setFromAccountModelToAccount(accountModel));
            AccountModel accountMapper = accountResponseMapper.setFromAccountToAccountModel(savedAccount);
            kafkaEventProducer.sendMessage(convertAccountToJson(generateAuditLog(accountMapper)));
            return accountMapper;
        } catch (Exception e) {
            return AccountModel.builder().build();
        }
    }

    private EventLog generateAuditLog(AccountModel account) throws JsonProcessingException {
        return EventLog.builder()
                .auditLog(UUID.randomUUID())
                .recordingUser("account")
                .recordingDate(LocalDate.now()).payload(account).build();
    }

    private String convertAccountToJson(EventLog eventLog) throws JsonProcessingException {
        return objectMapper.writeValueAsString(eventLog);
    }

}
