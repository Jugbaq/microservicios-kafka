package com.example.account.model.account;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Builder
public class AccountModel {
    private String idAccount;
    private String accountNumber;
    private String idCustomer;
    private String accountType;
    private String accountStatus;
    private BigDecimal accountBalance;
    private LocalDate openingDate;
}
