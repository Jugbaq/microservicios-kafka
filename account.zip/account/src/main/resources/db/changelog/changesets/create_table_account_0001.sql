CREATE TABLE account (
    id_account VARCHAR(36) PRIMARY KEY,
    number_account VARCHAR(16) NOT NULL,
    id_customer VARCHAR(36) NOT NULL,
    account_type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    account_balance DECIMAL(10, 2) DEFAULT 0.00,
    opening_date DATE NOT NULL
);