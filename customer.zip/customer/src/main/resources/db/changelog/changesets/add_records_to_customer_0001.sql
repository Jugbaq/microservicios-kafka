INSERT INTO customer (id_customer, first_name, last_name, status)
VALUES ('c831ef49-0755-4099-86f4-c9dfdbc8b4a9','Leonel','Messi','A');