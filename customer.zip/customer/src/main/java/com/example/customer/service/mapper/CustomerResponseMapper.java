package com.example.customer.service.mapper;

import com.example.customer.entity.Customer;
import com.example.customer.model.CustomerModel;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface CustomerResponseMapper {

    CustomerModel setFromCustomerToCustomerModel(Customer customer);

}
