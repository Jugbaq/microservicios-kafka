package com.example.customer.controller;

import com.example.customer.controller.mapper.CustomerMapper;
import com.example.customer.proxy.contract.CustomerManagementApi;
import com.example.customer.proxy.model.CustomerResponse;
import com.example.customer.service.CustomerService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
@RestController
public class CustomerController implements CustomerManagementApi {

    private final CustomerService customerService;
    private final CustomerMapper customerMapper;

    @Override
    public ResponseEntity<CustomerResponse> getCustomer(String idCustomer) {

        return Optional.ofNullable(customerService.getCustomerById(idCustomer))
                .map(customerModel -> {
                    CustomerResponse customerResponse = customerMapper.setFromCustomerModelToCustomerResponse(customerModel);
                    return ResponseEntity.ok(customerResponse);
                }).orElse(ResponseEntity.notFound().build());
    }

   /*
    private final CustomerMapper cardMapper;

    @Override
    public ResponseEntity<CardListResponse> listCards(String idCustomer) {
        List<CardsResponse> cardResponse = customerService.listCardsByCustomer(UUID.fromString(idCustomer))
                .stream()
                .map(cardMapper::setFromCardModelToCardsResponse)
                .collect(Collectors.toList());

        return cardResponse.isEmpty() ? ResponseEntity.noContent().build() :
                ResponseEntity.ok(new CardListResponse().tarjetas(cardResponse));
    }*/

}
