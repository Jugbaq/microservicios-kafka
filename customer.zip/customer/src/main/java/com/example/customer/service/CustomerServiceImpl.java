package com.example.customer.service;

import com.example.customer.entity.Customer;
import com.example.customer.model.CustomerModel;
import com.example.customer.repository.CustomerRepository;
import com.example.customer.service.mapper.CustomerResponseMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    private final CustomerResponseMapper customerResponseMapper;

    @Override
    public CustomerModel getCustomerById(String idCustomer) {
        Customer customer = customerRepository.findByIdCustomer(idCustomer);
        return (customer != null) ? customerResponseMapper.setFromCustomerToCustomerModel(customer) : CustomerModel.builder().build();
    }

}
