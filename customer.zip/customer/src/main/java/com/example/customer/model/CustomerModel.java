package com.example.customer.model;

import lombok.Builder;
import lombok.Getter;

import java.util.UUID;

@Getter
@Builder
public class CustomerModel {
    private UUID idCustomer;
    private String fistName;
    private String LastName;
    private String status;
}
