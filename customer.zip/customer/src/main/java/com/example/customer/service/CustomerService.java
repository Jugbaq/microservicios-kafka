package com.example.customer.service;

import com.example.customer.model.CustomerModel;

import java.util.UUID;

public interface CustomerService {
    CustomerModel getCustomerById(String idCustomer);
}
