package com.example.cards.controller;

import com.example.cards.controller.mapper.CardMapper;
import com.example.cards.proxy.contract.CardsManagementApi;
import com.example.cards.proxy.model.CardInput;
import com.example.cards.proxy.model.CardListResponse;
import com.example.cards.proxy.model.CardResponse;
import com.example.cards.proxy.model.CardsResponse;
import com.example.cards.service.CardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;


@RequiredArgsConstructor
@RestController
public class CardsController implements CardsManagementApi {

    private final CardService cardService;
    private final CardMapper cardMapper;

    @Override
    public ResponseEntity<CardListResponse> listCards(String idCustomer) {
        List<CardsResponse> cardResponse = cardService.listCardsByCustomer(UUID.fromString(idCustomer))
                .stream()
                .map(cardMapper::setFromCardModelToCardsResponse)
                .collect(Collectors.toList());

        return cardResponse.isEmpty() ? ResponseEntity.noContent().build() :
                ResponseEntity.ok(new CardListResponse().tarjetas(cardResponse));
    }

   @Override
    public ResponseEntity<CardResponse> registerCard(CardInput cardInput) {
       return Optional.ofNullable(cardService.saveCard(cardMapper.setFromCardInputToCardModel(cardInput)))
               .map(savedCard -> ResponseEntity.status(savedCard.getIdCard() != null ? HttpStatus.CREATED : HttpStatus.NO_CONTENT)
                       .body(cardMapper.setFromCardModelToCardResponse(savedCard)))
               .orElse(ResponseEntity.notFound().build());
    }
}
