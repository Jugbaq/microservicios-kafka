package com.example.cards.service;

import com.example.cards.model.CardModel;

import java.util.List;
import java.util.UUID;

public interface CardService {
    List<CardModel> listCardsByCustomer(UUID idCustomer);
    CardModel saveCard(CardModel cardInput);

}
