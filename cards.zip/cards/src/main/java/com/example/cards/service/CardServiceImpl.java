package com.example.cards.service;

import com.example.cards.client.CustomerClient;
import com.example.cards.entity.Card;
import com.example.cards.model.CardModel;
import com.example.cards.proxy.model.CardInput;
import com.example.cards.repository.CardRepository;
import com.example.cards.service.mapper.CardResponseMapper;
import com.example.cards.customer.model.thirdparty.CustomerResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CardServiceImpl implements CardService {

    private final CardRepository cardRepository;

    private final CardResponseMapper cardResponseMapper;

    private final CustomerClient customerClient;

    @Override
    public List<CardModel> listCardsByCustomer(UUID idCustomer) {

        return cardRepository.findByIdCustomer(idCustomer)
                .stream()
                .map(cardResponseMapper::setFromCardToCardModel)
                .collect(Collectors.toList());
    }

    @Override
    public CardModel saveCard(CardModel cardModel) {
        try {
            CustomerResponse customerResponse = customerClient.getCustomer(cardModel.getIdCustomer().toString());
            if (customerResponse != null && customerResponse.getCustomerStatus().equals("A")) {
                Card card = cardResponseMapper.setFromCardModelToCard(cardModel);
                Card savedCard = cardRepository.save(card);
                return cardResponseMapper.setFromCardToCardModel(savedCard);
            } else {
                return CardModel.builder().build();
            }
        } catch (Exception e) {
            return CardModel.builder().build();
        }
    }

}
