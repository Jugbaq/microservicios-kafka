package com.example.cards.client;

import com.example.cards.customer.model.thirdparty.CustomerResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="cards-microservice" , url="localhost:8081")
public interface CustomerClient {
    @GetMapping(value="/customer-management/customer/{idCustomer}")
    CustomerResponse getCustomer(@PathVariable("idCustomer") String idCustomer);
}
