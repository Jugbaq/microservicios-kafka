package com.example.cards.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Table(name="card")
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
public class Card implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id_card", columnDefinition = "uuid", updatable = false)
    private UUID idCard;

    @Column(name = "number_card")
    private String numberCard;

    @Column(name = "id_customer", columnDefinition = "uuid")
    private UUID idCustomer;

    @Column(name = "card_type")
    private String cardType;

    @Column(name = "status")
    private String status;

    @Column(name = "card_balance")
    private BigDecimal cardBalance;

    @Column(name = "card_limit")
    private BigDecimal cardLimit;

    @Column(name = "opening_date")
    private LocalDate openingDate;

    @Column(name = "expiration_date")
    private LocalDate expirationDate;

    @Column(name = "security_code")
    private String securityCode;
}
