package com.example.cards.controller.mapper;

import com.example.cards.entity.Card;
import com.example.cards.model.CardModel;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants.ComponentModel;
import com.example.cards.proxy.model.CardsResponse;
import com.example.cards.proxy.model.CardInput;
import com.example.cards.proxy.model.CardResponse;

@Mapper(componentModel = ComponentModel.SPRING)
public interface CardMapper {
    CardsResponse setFromCardModelToCardsResponse(CardModel card);

    CardModel setFromCardInputToCardModel(CardInput card);

    CardResponse setFromCardModelToCardResponse(CardModel card);
}
