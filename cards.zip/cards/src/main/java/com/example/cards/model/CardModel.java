package com.example.cards.model;

import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

@Getter
@Builder
public class CardModel {
    private UUID idCard;
    private String cardNumber;
    private UUID idCustomer;
    private String cardType;
    private String cardStatus;
    private BigDecimal cardBalance;
    private BigDecimal cardLimit;
    private LocalDate openingDate;
    private LocalDate expirationDate;
    private String securityCode;
}
