package com.example.cards.service.mapper;

import com.example.cards.entity.Card;
import com.example.cards.model.CardModel;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface CardResponseMapper {
    @Mapping(target="cardNumber", source = "numberCard")
    @Mapping(target="cardStatus", source = "status")
    CardModel setFromCardToCardModel(Card card);

    @Mapping(target="numberCard", source = "cardNumber")
    @Mapping(target="status", source = "cardStatus")
    Card setFromCardModelToCard(CardModel card);
}
