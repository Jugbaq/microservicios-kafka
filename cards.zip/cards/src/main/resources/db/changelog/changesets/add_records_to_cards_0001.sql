INSERT INTO card (number_card, id_customer, card_type, status, card_balance, card_limit, opening_date, expiration_date, security_code)
VALUES ('7894561237894561', 'c831ef49-0755-4099-86f4-c9dfdbc8b4a9', 'V', 'A', 1000.00, 5000.00, '2024-04-10', '2025-04-10', '123');
