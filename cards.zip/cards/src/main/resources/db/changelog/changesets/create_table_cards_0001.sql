CREATE TABLE card (
    id_card UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    number_card VARCHAR(16) NOT NULL,
    id_customer UUID NOT NULL,
    card_type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    card_balance DECIMAL(10, 2) DEFAULT 0.00,
    card_limit DECIMAL(10, 2) DEFAULT 0.00,
    opening_date DATE NOT NULL,
    expiration_date DATE NOT NULL,
    security_code VARCHAR(3) NOT NULL
);