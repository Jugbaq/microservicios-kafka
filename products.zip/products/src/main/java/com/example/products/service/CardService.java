package com.example.products.service;

import com.example.products.card.model.thirdparty.CardsResponse;
import com.example.products.client.CardClient;
import com.example.products.enums.ProductType;
import com.example.products.proxy.model.ProductResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class CardService implements ProductService {

    private final CardClient cardClient;

    @Override
    public List<ProductResponse> getCustomerProducts(String idCustomer) {

        return cardClient.getCustomer(idCustomer).getTarjetas().stream()
                .map(this::mapToProductResponse)
                .collect(Collectors.toList());
    }

    private ProductResponse mapToProductResponse(CardsResponse cardsResponse) {
        ProductResponse productResponse = new ProductResponse();
        productResponse.setIdProduct(cardsResponse.getIdCard());
        productResponse.setProductNumber(cardsResponse.getCardNumber());
        productResponse.setProductType(cardsResponse.getCardType());
        productResponse.setProductStatus(cardsResponse.getCardStatus());
        productResponse.setProductBalance(cardsResponse.getCardBalance());
        return productResponse;
    }

    @Override
    public ProductType getProductType() {
        return ProductType.CREDITCARD;
    }

}

