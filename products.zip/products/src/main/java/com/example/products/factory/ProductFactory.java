package com.example.products.factory;

import com.example.products.enums.ProductType;
import com.example.products.service.ProductService;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

@Service
public class ProductFactory implements InitializingBean {

    private List<ProductService> productTypeStrategies;
    private Map<ProductType, ProductService> strategies;

    public ProductFactory(List<ProductService> strategyList) {
        this.productTypeStrategies = strategyList;
    }

    public ProductService findStrategy(ProductType strategyName) {
        return strategies.get(strategyName);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.strategies = new EnumMap<>(ProductType.class);
        productTypeStrategies.forEach(
                strategy -> strategies.put(strategy.getProductType(), strategy));
    }
}

