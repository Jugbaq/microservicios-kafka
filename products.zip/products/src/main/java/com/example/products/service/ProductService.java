package com.example.products.service;

import com.example.products.enums.ProductType;
import com.example.products.proxy.model.ProductResponse;

import java.util.List;

public interface ProductService {

    List<ProductResponse> getCustomerProducts(String idCustomer);

    ProductType getProductType();
}

