package com.example.products.client;

import com.example.products.card.model.thirdparty.CardListResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name="card-microservice" , url="localhost:8080")
public interface CardClient {
    @GetMapping(value="/cards-management/cards/{idCustomer}")
    CardListResponse getCustomer(@PathVariable("idCustomer") String idCustomer);
}
