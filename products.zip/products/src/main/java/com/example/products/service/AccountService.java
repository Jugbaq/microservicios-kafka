package com.example.products.service;

import com.example.products.enums.ProductType;
import com.example.products.proxy.model.ProductResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AccountService implements ProductService {

    @Override
    public List<ProductResponse> getCustomerProducts(String idCustomer) {

        return new ArrayList<>();
    }

    @Override
    public ProductType getProductType() {
        return ProductType.ACCOUNT;
    }

}

