package com.example.products.controller;

import com.example.products.manager.ProductManager;
import com.example.products.proxy.model.ProductListResponse;
import com.example.products.proxy.model.ProductResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import com.example.products.proxy.contract.ProductManagementApi;


@RequiredArgsConstructor
@RestController
public class ProductsController implements ProductManagementApi {

    private final ProductManager productManager;

    @Override
    public ResponseEntity<ProductListResponse> listProducts(String idCustomer, String productType) {
        List <ProductResponse> productResponse =  productManager.getCustomerProducts(idCustomer, productType);
        return productResponse.isEmpty() ? ResponseEntity.noContent().build() :
                ResponseEntity.ok(new ProductListResponse().products(productResponse));

    }
}
