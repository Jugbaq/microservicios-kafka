package com.example.products.enums;

public enum ProductType {
    CREDITCARD,
    ACCOUNT;
}
