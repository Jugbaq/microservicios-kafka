package com.example.products.manager;

import com.example.products.enums.ProductType;
import com.example.products.factory.ProductFactory;
import com.example.products.proxy.model.ProductResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductManager {

    private final ProductFactory productFactory;

    public List<ProductResponse> getCustomerProducts(String personId, String productType) {
        return productFactory
                .findStrategy(ProductType.valueOf(productType))
                .getCustomerProducts(personId);
    }
}

